#include<iostream>
using namespace std;
#define num(a,b) ( (a>b)? a:b)

int main(){
   
        cout << num(256,786) << endl;
    
    return 0;
}

/*
786
*/